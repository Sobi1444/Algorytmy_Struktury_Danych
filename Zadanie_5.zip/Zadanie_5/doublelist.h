#ifndef DOUBLELIST_H
#define DOUBLELIST_H

#include <cassert>
#include <iostream>

template <typename T>
struct DoubleNode {
    T value;
    DoubleNode *next, *prev;
    DoubleNode() : value(T()), next(nullptr), prev(nullptr) {}
    DoubleNode(const T& item, DoubleNode *nptr=nullptr, DoubleNode *pptr=nullptr)
        : value(item), next(nptr), prev(pptr) {}
    ~DoubleNode() {}
};

template <typename T>
class DoubleList {
    DoubleNode<T> *head, *tail;
public:
    DoubleList() : head(nullptr), tail(nullptr) {}
    ~DoubleList() { clear(); }
    
    // konstruktor kopiujacy
    DoubleList(const DoubleList& other) : head(nullptr), tail(nullptr) {
        DoubleNode<T>* cur = other.head;
        while (cur) {
            push_back(cur->value);
            cur = cur->next;
        }
    }

    // operator przypisania =
    DoubleList& operator=(const DoubleList& other) {
        if (this == &other) return *this;
        clear();
        DoubleNode<T>* cur = other.head;
        while (cur) {
            push_back(cur->value);
            cur = cur->next;
        }
        return *this;
    }

    bool empty() const { return head == nullptr; }

    void push_front(const T& item) {
        DoubleNode<T> *node = new DoubleNode<T>(item, head, nullptr);
        if (head) head->prev = node;
        head = node;
        if (!tail) tail = node;
    }

    void push_back(const T& item) {
        DoubleNode<T> *node = new DoubleNode<T>(item, nullptr, tail);
        if (tail) tail->next = node;
        tail = node;
        if (!head) head = node;
    }

    void pop_front() {
        assert(!empty());
        DoubleNode<T> *tmp = head;
        head = head->next;
        if (head) head->prev = nullptr;
        else tail = nullptr;
        delete tmp;
    }

    void pop_back() {
        assert(!empty());
        DoubleNode<T> *tmp = tail;
        tail = tail->prev;
        if (tail) tail->next = nullptr;
        else head = nullptr;
        delete tmp;
    }

    T& front() const { assert(!empty()); return head->value; }
    T& back() const { assert(!empty()); return tail->value; }

    void clear() {
        while (!empty()) pop_front();
    }

    void display() const {
        DoubleNode<T> *cur = head;
        while (cur) {
            std::cout << cur->value << " ";
            cur = cur->next;
        }
        std::cout << "\n";
    }

    void display_reversed() const {
        DoubleNode<T> *cur = tail;
        while (cur) {
            std::cout << cur->value << " ";
            cur = cur->prev;
        }
        std::cout << "\n";
    }

    std::size_t size() const {
        std::size_t count = 0;
        DoubleNode<T> *cur = head;
        while (cur) {
            ++count;
            cur = cur->next;
        }
        return count;
    }
};

#endif