#ifndef DEQUE_H
#define DEQUE_H

#include <cassert>
#include <iostream>

template <typename T>
class Deque {
    T* tab;
    std::size_t msize;
    std::size_t head;  // pierwszy element
    std::size_t tail;  // pierwsza wolna pozycja

public:

    // konstruktor
    Deque(std::size_t s = 10) : msize(s+1), head(0), tail(0) {
        tab = new T[msize];
        assert(tab != nullptr);
    }

    // destruktor
    ~Deque() {
        delete [] tab;
    }

    // konstruktor kopiujący
    Deque(const Deque& other)
        : msize(other.msize), head(other.head), tail(other.tail) 
    {
        tab = new T[msize];
        for (std::size_t i = 0; i < msize; i++)
            tab[i] = other.tab[i];
    }

    // operator przypisania
    Deque& operator=(const Deque& other) {
        if (this == &other) return *this;

        delete [] tab;

        msize = other.msize;
        head = other.head;
        tail = other.tail;

        tab = new T[msize];
        for (std::size_t i = 0; i < msize; i++)
            tab[i] = other.tab[i];

        return *this;
    }

    // podstawowe metody
    bool empty() const { return head == tail; }
    bool full() const { return (tail + 1) % msize == head; }
    std::size_t size() const { return (tail - head + msize) % msize; }
    std::size_t max_size() const { return msize - 1; }

    // wstawianie
    void push_front(const T& item) {
        assert(!full());
        head = (head + msize - 1) % msize;
        tab[head] = item;
    }

    void push_back(const T& item) {
        assert(!full());
        tab[tail] = item;
        tail = (tail + 1) % msize;
    }

    // dostep
    T& front() {
        assert(!empty());
        return tab[head];
    }

    T& back() {
        assert(!empty());
        return tab[(tail + msize - 1) % msize];
    }

    // usuwanie
    void pop_front() {
        assert(!empty());
        head = (head + 1) % msize;
    }

    void pop_back() {
        assert(!empty());
        tail = (tail + msize - 1) % msize;
    }

    // czyszczenie
    void clear() {
        head = tail = 0;
    }

    // wyswietlanie
    void display() {
        for (std::size_t i = head; i != tail; i = (i + 1) % msize)
            std::cout << tab[i] << " ";
        std::cout << std::endl;
    }

    void display_reversed() {
        if (empty()) { std::cout << std::endl; return; }

        std::size_t i = (tail + msize - 1) % msize;
        while (true) {
            std::cout << tab[i] << " ";
            if (i == head) break;
            i = (i + msize - 1) % msize;
        }
        std::cout << std::endl;
    }
};

#endif