#include <iostream>
#include "deque.h"

int main() {
    Deque<int> Q(4);  // maks 4 elementy

    Q.push_back(11);
    Q.push_back(22);
    Q.push_front(33);
    Q.push_front(44);

    std::cout << "Zawartosc: ";
    Q.display();  // 44 33 11 22

    std::cout << "przod = " << Q.front() << "\n";
    std::cout << "tyl  = " << Q.back() << "\n";

    Q.pop_front();
    Q.pop_back();

    std::cout << "Po usunieciu front i back: ";
    Q.display(); // 33 11

    Q.clear();
    std::cout << "Puste? " << Q.empty() << "\n";

    return 0;
}