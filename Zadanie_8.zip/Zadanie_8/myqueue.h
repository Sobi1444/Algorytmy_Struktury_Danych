#ifndef MYQUEUE_H
#define MYQUEUE_H

#include <cassert>
#include <cstddef>
#include <utility>
#include <iostream>

template <typename T>
class MyQueue {
    T* tab;
    std::size_t msize; // maksymalny rozmiar + 1
    std::size_t head;  // indeks pierwszego elementu
    std::size_t tail;  // indeks pierwszej wolnej pozycji

public:
    // KONSTRUKTOR
    MyQueue(std::size_t s = 10)
        : msize(s + 1), head(0), tail(0)
    {
        tab = new T[msize];
        assert(tab != nullptr);
    }

    // DESTRUKTOR
    ~MyQueue() {
        delete[] tab;
    }

    // KONSTRUKTOR KOPIUJACY
    MyQueue(const MyQueue& other)
        : msize(other.msize), head(other.head), tail(other.tail)
    {
        tab = new T[msize];
        for (std::size_t i = 0; i < msize; i++)
            tab[i] = other.tab[i];
    }

    // KONSTRUKTOR PRZENOSZACY
    MyQueue(MyQueue&& other)
        : tab(other.tab), msize(other.msize), head(other.head), tail(other.tail)
    {
        other.tab = nullptr;
        other.msize = 1;
        other.head = 0;
        other.tail = 0;
    }

    // OPERATOR KOPIUJACY
    MyQueue& operator=(const MyQueue& other)
    {
        if (this == &other)
            return *this;

        delete[] tab;

        msize = other.msize;
        head = other.head;
        tail = other.tail;

        tab = new T[msize];
        for (std::size_t i = 0; i < msize; i++)
            tab[i] = other.tab[i];

        return *this;
    }

    // OPERATOR PRZENOSZACY
    MyQueue& operator=(MyQueue&& other)
    {
        if (this == &other)
            return *this;

        delete[] tab;

        tab = other.tab;
        msize = other.msize;
        head = other.head;
        tail = other.tail;

        other.tab = nullptr;
        other.msize = 1;
        other.head = 0;
        other.tail = 0;

        return *this;
    }

    // PODSTAWOWE METODY
    bool empty() const {
        return head == tail;
    }

    bool full() const {
        return (head + msize - 1) % msize == tail;
    }

    std::size_t size() const {
        return (tail - head + msize) % msize;
    }

    std::size_t max_size() const {
        return msize - 1;
    }

    // DODAWANIE ELEMENTU
    void push(const T& item) {
        assert(!full());
        tab[tail] = item;
        tail = (tail + 1) % msize;
    }

    void push(T&& item) {
        assert(!full());
        tab[tail] = std::move(item);
        tail = (tail + 1) % msize;
    }

    // DOSTEP DO POCZATKU I KONCA
    T& front() {
        assert(!empty());
        return tab[head];
    }

    T& back() {
        assert(!empty());
        return tab[(tail + msize - 1) % msize];
    }

    // USUWANIE POCZATKU
    void pop() {
        assert(!empty());
        head = (head + 1) % msize;
    }

    // CZYSZCZENIE KOLEJKI
    void clear() {
        head = tail = 0;
    }

    // WYSWIETLANIE KOLEJKI
    void display() {
        std::size_t i = head;
        while (i != tail) {
            std::cout << tab[i] << " ";
            i = (i + 1) % msize;
        }
        std::cout << "\n";
    }
};

#endif