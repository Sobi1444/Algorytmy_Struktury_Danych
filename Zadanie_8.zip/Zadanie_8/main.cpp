#include <iostream>
#include <cassert>
#include "myqueue.h"

int main() {
    MyQueue<int> q(5);  // kolejka max 5 elementow

    assert(q.empty());   // kolejka powinna byc pusta
    q.push(10);
    q.push(20);
    q.push(30);

    assert(q.size() == 3);
    assert(q.front() == 10);
    assert(q.back() == 30);

    q.pop();
    assert(q.front() == 20);

    q.clear();
    assert(q.empty());

    std::cout << "Dziala" << std::endl;
    return 0;
}