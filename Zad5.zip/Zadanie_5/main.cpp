#include "doublelist.h"
#include <cassert>

int main() {
    DoubleList<int> list;

    assert(list.empty());
    list.push_back(1);
    list.push_back(2);
    list.push_front(0);

    list.display();           //0 1 2
    list.display_reversed();  //2 1 0

    assert(list.front() == 0);
    assert(list.back() == 2);
    assert(list.size() == 3);

    list.pop_front();
    list.pop_back();
    list.display();//1
    assert(list.size() == 1);

    list.clear();
    assert(list.empty());

    return 0;
}