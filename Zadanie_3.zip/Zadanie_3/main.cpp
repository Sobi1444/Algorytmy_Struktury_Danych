#include "arraylist.h"
#include <iostream>

int main() {
    ArrayList<int> lista(10);

    // dodanie lementow
    lista.push_back(200);
    lista.push_back(10);
    lista.push_front(30);

    std::cout << "Lista po dodaniu elementow: ";
    lista.display(); 

  
    lista.pop_front();//usun przod
    lista.pop_back();//usun tyl

    std::cout << "Lista po usunieciu przodu i tylu: ";
    lista.display();

    std::cout << "Pierwszy element: " << lista.front() << std::endl;
    std::cout << "Ostatni element: " << lista.back() << std::endl;
    std::cout << "Rozmiar: " << lista.size() << " / " << lista.max_size() << std::endl;

    lista.clear();
    std::cout << "Po clear(): " << (lista.empty() ? "lista jest pusta" : "lista nie jest pusta") << std::endl;

    return 0;
}