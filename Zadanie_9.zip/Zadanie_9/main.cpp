#include <iostream>
#include <stack>
#include <queue>
#include <cassert>

using namespace std;

template <typename T>
struct BSTNode {
    T value;
    BSTNode *left, *right;
    
    BSTNode() : value(T()), left(nullptr), right(nullptr) {}
    BSTNode(const T& item) : value(item), left(nullptr), right(nullptr) {}
    ~BSTNode() { delete left; delete right; }
};

template <typename T>
class RandomBinaryTree {
    BSTNode<T> *root;
public:
    RandomBinaryTree() : root(nullptr) {}
    ~RandomBinaryTree() { delete root; }
    void clear() { delete root; root = nullptr; }
    bool empty() const { return root == nullptr; }
    T& top() { assert(root != nullptr); return root->value; }
    void insert(const T& item) { root = insert(root, item); }
    
    int calc_nodes_recursive() { return calc_nodes_recursive(root); }
    int calc_nodes_iterative();
    
    BSTNode<T>* insert(BSTNode<T>* node, const T& item);
    void display(BSTNode<T>* node, int level);
    void display() { display(root, 0); }
    
private:
    int calc_nodes_recursive(BSTNode<T>* node);
};

template <typename T>
void RandomBinaryTree<T>::display(BSTNode<T>* node, int level) {
    if (node == nullptr) return;
    display(node->right, level + 1);
    for (int i = 0; i < level; i++) {
        cout << "   |";
    }
    cout << "---" << node->value << endl;
    display(node->left, level + 1);
}

template <typename T>
BSTNode<T>* RandomBinaryTree<T>::insert(BSTNode<T>* node, const T& item) {
    if (node == nullptr) {
        return new BSTNode<T>(item);
    }
    if (rand() % 2) {
        node->left = insert(node->left, item);
    } else {
        node->right = insert(node->right, item);
    }
    return node;
}

template <typename T>
int RandomBinaryTree<T>::calc_nodes_recursive(BSTNode<T>* node) {
    // funkcja zwraca 0 dla pustego wezla
    if (node == nullptr) {
        return 0;
    }
    
    // funkcja liczy wezly jako: 1 (biezacy wezel) + wezly lewego poddrzewa + wezly prawego poddrzewa
    return 1 + calc_nodes_recursive(node->left) + calc_nodes_recursive(node->right);
}

template <typename T>
int RandomBinaryTree<T>::calc_nodes_iterative() {
    // funkcja zwraca 0 dla pustego drzewa
    if (root == nullptr) {
        return 0;
    }
    
    stack<BSTNode<T>*> s;
    int count = 0;
    
    BSTNode<T>* current = root;
    s.push(current);
    
    while (!s.empty()) {
        current = s.top();
        s.pop();
        
        // inkrementacja licznika wezlow
        count++;
        
        // dodanie prawego dziecka na stos jesli istnieje
        if (current->right != nullptr) {
            s.push(current->right);
        }
        
        // dodanie lewego dziecka na stos jesli istnieje
        if (current->left != nullptr) {
            s.push(current->left);
        }
    }
    
    return count;
}

int main() {
    RandomBinaryTree<int> tree;
    
    cout << "tworzenie przykladowego drzewa..." << endl;
    tree.insert(10);
    tree.insert(5);
    tree.insert(15);
    tree.insert(3);
    tree.insert(7);
    tree.insert(12);
    tree.insert(18);
    
    cout << "\nstruktura drzewa:" << endl;
    tree.display();
    
    cout << "\nzliczanie wezlow:" << endl;
    cout << "wersja rekurencyjna: " << tree.calc_nodes_recursive() << endl;
    cout << "wersja iteracyjna: " << tree.calc_nodes_iterative() << endl;
    
    RandomBinaryTree<int> emptyTree;
    cout << "\ntest z pustym drzewem:" << endl;
    cout << "wersja rekurencyjna: " << emptyTree.calc_nodes_recursive() << endl;
    cout << "wersja iteracyjna: " << emptyTree.calc_nodes_iterative() << endl;
    
    return 0;
}