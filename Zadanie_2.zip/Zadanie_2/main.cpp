#include <iostream>
#include <vector>
#include <cassert>
#include "algo_sort.hpp"

int main() {
    std::vector<int> tablica1 = {5,2,900,12000,5,60};
    std::vector<int> tablica2 = tablica1; // dla quickSorta

    std::cout << "Przed sortowaniem:\n";
    // auto -> automatycznie dopasuje typ zmiennej i do elementu tablicy
    for (auto i : tablica1) 
    std::cout << i << " ";

    std::cout << "\n";

    bubbleSort(tablica1.begin(), tablica1.end());
    quickSort(tablica2.begin(), tablica2.end());

    std::cout << "Bubble Sort:\n";
    for (auto i : tablica1) std::cout << i << " ";
    std::cout << "\n";

    std::cout << "Quick Sort:\n";
    for (auto i : tablica2) std::cout << i << " ";
    std::cout << "\n";

    //sprawdzenie poprawnosci sortowania przez Bubble Sort i Quick Sort
    assert(std::is_sorted(tablica1.begin(), tablica1.end()));
    assert(std::is_sorted(tablica2.begin(), tablica2.end()));
    
    return 0;
}