#ifndef ALGO_SORT_HPP
#define ALGO_SORT_HPP

#include <iterator>
#include <algorithm>

// BUBBLE SORT
template<typename Iterator> //naglowek szablonu funkcji, powoduje ze funkcja bubblesort moze dzialac dla kazdego typu iteratora np int, double, string
void bubbleSort(Iterator begin, Iterator end) {
    bool zmieniony;
    do {
        zmieniony = false;
        //petla konczy dzialanie gdy i = ostatni element, end tzn poza tablica
        // iterator wskazuje polozenie w tablicy
        for (Iterator i = begin; std::next(i) != end; ++i) {
            Iterator j = std::next(i);
            if (*j < *i) { // *i, *j to wartosc elementu na ktory wskazuja te iteratory
                std::iter_swap(i,j); //zamiana miejscami wartosci na ktore wskazuja iteratory i,j
                zmieniony = true; //zmieniony szyk przy pojedynczym przejsciu petli

            }
        }
    }
    while (zmieniony); // jezeli zmieniono szyk, to spowoduje ze znow uruchomi sie funkcja do
}

// QUICK SORT
template<typename Iterator>
void quickSort(Iterator begin, Iterator end) {
    
    //WYKONANIE PODZIALU NA PODTABLICE
    //lewa strona elementy <= aktualny
    //prawa strona elementy >= aktualny <--- element rowny aktualny jest po lewej lub prawej, nie naraz
    //jezeli liczba elementow pomiedzy iteratorami jest <=1 tzn ze przedzial jest posortowany
    if (std::distance(begin, end) <= 1) {
        return;
    }

    Iterator aktualny = begin;
    Iterator left = begin;
    Iterator right = std::prev(end); // end-1

    while (left <= right) {

        while (*left < *aktualny) 
        ++left;
        while (*right > *aktualny)
        --right;

        if (left <= right) {
            std::iter_swap(left, right);
            ++left;
            if (right != begin) 
            --right;
        }
    }

    quickSort(begin, right + 1); // konwencja [begin, right+1), stad +1, zeby zawrzec element right
    quickSort(left, end); // [left, end)
}

#endif