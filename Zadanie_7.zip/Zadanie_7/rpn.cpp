#include <iostream>
#include <vector>
#include <stack>
#include <string>
#include <cassert>
#include <cstdlib>

int rpn(const std::vector<std::string>& input) {
    std::stack<int> S;
    for (auto& token : input) {
        if (token == "+" || token == "-" || token == "*" || token == "/") {
            int a = S.top(); S.pop();
            int b = S.top(); S.pop();
            if (token == "+") S.push(b + a);
            else if (token == "-") S.push(b - a);
            else if (token == "*") S.push(b * a);
            else if (token == "/") S.push(b / a);
        } else {
            S.push(std::stoi(token));
        }
    }
    return S.top();
}

int main() {
    std::vector<std::string> expr1 {"5", "7", "+", "3", "*"};
    assert(rpn(expr1) == 36);

    std::vector<std::string> expr2 {"8", "4", "/"};
    assert(rpn(expr2) == 2);

    std::vector<std::string> expr3 {"-3", "6", "-"};
    assert(rpn(expr3) == -9);

    std::cout << "Wszystkie testy ok" << std::endl;
    return 0;
}