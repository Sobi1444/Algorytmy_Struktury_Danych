#include "singlelist.h"
#include <cassert>

int main() {
    SingleList<int> list;
    assert(list.empty());
    assert(list.size() == 0);

    list.push_back(10);
    list.push_front(5);
    list.push_back(20);
    assert(list.size() == 3);
    assert(list.front() == 5);
    assert(list.back() == 20);

    list.pop_front();  // usunie 5
    assert(list.front() == 10);

    list.pop_back();   // usunie 20
    assert(list.back() == 10);
    assert(list.size() == 1);

    list.clear();
    assert(list.empty());

    std::cout << "Wszystkie testy przeszly" << std::endl;
}